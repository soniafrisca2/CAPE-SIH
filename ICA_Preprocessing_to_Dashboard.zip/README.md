# ICA: Pre-processing → Dashboard (satu notebook)

`ICA_Preprocessing_to_Dashboard.ipynb`: data di-load sekali, semua section memakai variabel di memori.
Jalankan **Run All** dari atas. Perkiraan waktu di Colab A100: ±15–30 menit (paling lama di section 8, modelling).

| Section | Isi |
|---|---|
| 0 | Setup path & framework guardrail (`guard()`, audit log, fail-closed) |
| 1 | Load data + Input Guardrail: kontrak data, deteksi & masking PII, fingerprint file |
| 2–5 | Cek kualitas data, pre-processing, EDA, ringkasan insight |
| 6–7 | Feature engineering, split, feature selection + Process Guardrail (point-in-time, anti-leakage, fairness) |
| 8–9 | Modelling LogReg / Random Forest / XGBoost × baseline / FE + quality gate, interpretabilitas |
| 10 | Output Guardrail: validitas skor, OOD, zona Further Review, disparate impact |
| 11 | Monitoring & Audit: PSI baseline, model card, simpan artefak |
| 12 | Dashboard threshold interaktif (Credit Risk & Early Warning) |
| 13 | Ringkasan guardrail + rencana guardrail GenAI / Agentic AI |

## Lokasi data (otomatis)
Urutan pencarian: env `ICA_DATA_DIR` → folder kerja → `/content` (hasil *Upload to Colab*) → Google Drive yang sudah di-mount
(`/content/drive/MyDrive[/ICA_Synthetic_v4]`) → **download otomatis** dari link Google Drive (harus *Anyone with the link*).

Kernel Colab di VS Code tidak bisa membaca file lokal di laptop secara langsung. Mount Drive (Command Palette →
*Colab: Mount Google Drive to Server*) kalau mau artefak di `ica_artifacts` tersimpan permanen.

## Output (`ica_artifacts/`)
`audit_log.jsonl` · `model_card.json` · `model_registry.json` · `monitoring_baseline.json` · `model_{cr_new,cr_existing,ew}.joblib` ·
`test_predictions.joblib` · `03_results.csv` · `ica_threshold_dashboard.html`. Semuanya dipakai notebook GenAI / Agentic AI berikutnya.

## Catatan
- `STRICT = True` (section 0): cek kritis yang gagal menghentikan notebook. Ubah ke `False` hanya untuk debugging.
- `FAST_MODE` (section 8) hanya untuk uji cepat (env `ICA_FAST=1`). Biarkan `False` untuk hasil final.
- XGBoost otomatis memakai GPU kalau `nvidia-smi` terdeteksi.
