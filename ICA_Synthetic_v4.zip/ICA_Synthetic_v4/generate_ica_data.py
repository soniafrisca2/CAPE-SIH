"""
ICA Synthetic Data Generator v4
================================
Satu variabel laten per nasabah (`z` = tekanan finansial tersembunyi) menggerakkan:
  - jawaban interview (new applicant),
  - perilaku bayar bulanan (existing customer),
  - probabilitas default aplikasi.
Dengan begitu profil, interview, perilaku, DPD, dan label saling konsisten.

Definisi label:
  credit_application.default_12m      = 1 jika DPD >= 90 (kolektibilitas 3-5 OJK)
                                         terjadi dalam 12 bulan setelah pencairan.
  monthly_behavior.deterioration_next_1m = 1 jika bucket DPD bulan depan lebih buruk
                                         dari bulan ini (bucket: 0 | 1-29 | 30-59 | 60-89 | 90+).
  monthly_behavior.default_next_3m    = 1 jika DPD >= 90 tercapai dalam 3 bulan ke depan.

Usage: python generate_ica_data.py <output_dir>
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
rng = np.random.default_rng(SEED)
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("ICA_Synthetic_v4")
OUT.mkdir(parents=True, exist_ok=True)

N_EX, N_NEW = 8000, 4000
N = N_EX + N_NEW
DATA_END = pd.Timestamp("2025-12-31")
MONTHS = pd.date_range("2024-01-31", "2025-12-31", freq="ME")  # 24 snapshot
T = len(MONTHS)
TARGET_PD = {"existing": 0.085, "new": 0.12}


def sig(x):
    return 1 / (1 + np.exp(-x))


def annuity(p, rate_pct, n):
    r = rate_pct / 1200.0
    return p * r / (1 - (1 + r) ** (-n))


def principal_from_pmt(pmt, rate_pct, n):
    r = rate_pct / 1200.0
    return pmt * (1 - (1 + r) ** (-n)) / r


def balance_after(p, rate_pct, n, k):
    """Sisa pokok anuitas setelah k cicilan."""
    r = rate_pct / 1200.0
    k = np.clip(k, 0, n)
    return p * ((1 + r) ** n - (1 + r) ** k) / ((1 + r) ** n - 1)


def month_idx(ts):
    ts = pd.to_datetime(ts)
    return (ts.year - 2024) * 12 + ts.month - 1


def rand_dates(start, end, n):
    s, e = pd.Timestamp(start).value // 10**9, pd.Timestamp(end).value // 10**9
    return pd.to_datetime(rng.integers(s, e, n), unit="s").normalize()


# ------------------------------------------------------------------ 1. PROFILE
cust_id = np.array([f"CUST{i:05d}" for i in range(1, N + 1)])
is_ex = np.arange(N) < N_EX
status = np.where(is_ex, "existing", "new")

emp = rng.choice(["Salaried", "Business Owner", "Self-employed", "Contract"], N, p=[.56, .17, .17, .10])
biz = np.isin(emp, ["Business Owner", "Self-employed"])
age_mu = np.select([emp == "Contract", emp == "Business Owner", emp == "Self-employed"], [29, 42, 38], 36)
age = np.clip(np.round(rng.normal(age_mu, 8)), 21, 60).astype(int)
gender = rng.choice(["Male", "Female"], N, p=[.52, .48])
pm = sig((age - 28) / 4) * 0.85
u = rng.random(N)
marital = np.where(u < pm, "Married", np.where((u < pm + 0.07) & (age > 30), "Divorced", "Single"))
dependents = np.select(
    [marital == "Married", marital == "Divorced"],
    [np.clip(rng.poisson(1.5, N), 0, 4), np.clip(rng.poisson(1.0, N), 0, 3)],
    np.clip(rng.poisson(0.15, N), 0, 2),
)
ten = np.select(
    [emp == "Contract", emp == "Salaried"],
    [rng.integers(3, 37, N), rng.exponential(55, N) + 6],
    rng.exponential(75, N) + 12,
)
ten = np.clip(np.round(ten), 3, np.maximum((age - 20) * 12, 3)).astype(int)
city = rng.choice(["Jakarta", "Surabaya", "Bandung", "Medan", "Semarang", "Makassar", "Yogyakarta"], N,
                  p=[.30, .16, .14, .12, .10, .09, .09])
med = {"Salaried": 9.0e6, "Contract": 6.0e6, "Self-employed": 8.5e6, "Business Owner": 14e6}
sdv = {"Salaried": .45, "Contract": .35, "Self-employed": .6, "Business Owner": .65}
income = np.array([med[e] for e in emp]) * np.exp(np.array([sdv[e] for e in emp]) * rng.standard_normal(N))
income *= np.exp(0.012 * (age - 36) + 0.002 * np.minimum(ten, 120)) * np.where(city == "Jakarta", 1.15, 1.0)
income = np.clip(np.round(income, -3), 3.5e6, 2.5e8)
income_source = np.where(
    biz, np.where(rng.random(N) < .8, "Business", "Mixed"), np.where(rng.random(N) < .88, "Salary", "Mixed")
)
segment = np.select([income < 9e6, income < 25e6], ["Mass", "Upper Mass"], "Affluent")

# Laten: tekanan finansial tersembunyi (tidak diekspor)
z = rng.standard_normal(N) + np.select([emp == "Contract", emp == "Self-employed"], [.35, .15], 0) \
    + 0.2 * (age < 25) + 0.05 * dependents

# ------------------------------------------------------------------ 2. APPLICATION
app_date = rand_dates("2024-07-01", "2024-12-31", N)
p_type_biz = np.array([.25, .50, .15, .10])
p_type_sal = np.array([.55, .03, .25, .17])
types = np.array(["Personal Loan", "Business Loan", "Auto Loan", "Home Loan"])
loan_type = np.where(biz, rng.choice(types, N, p=p_type_biz), rng.choice(types, N, p=p_type_sal / p_type_sal.sum()))

purpose_map = {
    "Personal Loan": (["Consumption", "Education", "Emergency", "Renovation", "Debt Consolidation"],
                      [.38, .20, .17, .15, .10]),
    "Auto Loan": (["Vehicle Purchase"], [1.0]),
    "Home Loan": (["Home Purchase", "Renovation"], [.75, .25]),
    "Business Loan": (["Working Capital", "Business Expansion"], [.65, .35]),
}
loan_purpose = np.empty(N, dtype=object)
for lt, (cats, ps) in purpose_map.items():
    m = loan_type == lt
    loan_purpose[m] = rng.choice(cats, m.sum(), p=ps)

tenor_opts = {"Personal Loan": [12, 24, 36], "Auto Loan": [24, 36, 48, 60], "Home Loan": [120, 180, 240],
              "Business Loan": [12, 24, 36, 48]}
mult = {"Personal Loan": (2, 8), "Auto Loan": (10, 28), "Home Loan": (30, 90), "Business Loan": (4, 18)}
clip_amt = {"Personal Loan": (5e6, 2e8), "Auto Loan": (8e7, 8e8), "Home Loan": (2e8, 3e9),
            "Business Loan": (2.5e7, 1.5e9)}
rate_rng = {"Personal Loan": (11, 18), "Auto Loan": (7.5, 12), "Home Loan": (7, 10.5), "Business Loan": (9, 15)}
tenor = np.zeros(N, int)
desired = np.zeros(N)
rate = np.zeros(N)
for lt in types:
    m = loan_type == lt
    tenor[m] = rng.choice(tenor_opts[lt], m.sum())
    lo, hi = mult[lt]
    desired[m] = np.clip(income[m] * rng.uniform(lo, hi, m.sum()), *clip_amt[lt])
    rate[m] = np.round(rng.uniform(*rate_rng[lt], m.sum()), 2)

channel = rng.choice(["Branch", "Online", "Referral"], N, p=[.45, .40, .15])

# ------------------------------------------------------------------ 3. PRE-EXISTING ACCOUNTS (existing)
acc_rows = []
acc_prod_biz = (["Credit Card", "Personal Loan", "Business Loan", "Auto Loan"], [.40, .20, .25, .15])
acc_prod_sal = (["Credit Card", "Personal Loan", "Auto Loan"], [.50, .30, .20])
acc_tenor = {"Personal Loan": [12, 24, 36], "Auto Loan": [36, 48, 60], "Business Loan": [12, 24, 36]}
acc_rate = {"Credit Card": (18, 30), "Personal Loan": (11, 18), "Auto Loan": (7.5, 12), "Business Loan": (9, 15)}
base_u = rng.normal(-0.9, 0.6, N) + 0.35 * z  # kecenderungan utilisasi kartu
for i in np.where(is_ex)[0]:
    k = 1 + min(rng.poisson(0.25), 2)
    for j in range(k):
        cats, ps = acc_prod_biz if biz[i] else acc_prod_sal
        prod = "Credit Card" if (j == 0 and rng.random() < .65) else rng.choice(cats, p=ps)
        if j == 0 and prod != "Credit Card" and prod not in acc_tenor:
            prod = "Credit Card"
        if prod == "Credit Card":
            ten_m = 0
            od = rand_dates("2016-01-01", "2023-12-15", 1)[0]
            prin = float(np.clip(np.round(income[i] * rng.uniform(1.5, 4), -6), 3e6, 1e8))
        else:
            opts = [t for t in acc_tenor[prod] if (j > 0 or t >= 24)]
            ten_m = int(rng.choice(opts))
            lo = max(pd.Timestamp("2015-01-01"), MONTHS[0] - pd.DateOffset(months=ten_m - (13 if j == 0 else 3)))
            od = rand_dates(lo, "2023-12-15", 1)[0]
            m_lo, m_hi = {"Personal Loan": (2, 6), "Auto Loan": (8, 20), "Business Loan": (3, 12)}[prod]
            prin = float(np.round(income[i] * rng.uniform(m_lo, m_hi), -5))
        acc_rows.append(dict(cust=i, product_type=prod, open_date=od, principal=prin,
                             interest_rate=round(rng.uniform(*acc_rate[prod]), 2), tenor_months=ten_m,
                             application_id=None))
acc = pd.DataFrame(acc_rows)

# Kewajiban existing saat aplikasi (bank sendiri + lembaga lain via SLIK)
ex_debt = np.zeros(N)
for r in acc.itertuples():
    ad = app_date[r.cust]
    if r.product_type == "Credit Card":
        ex_debt[r.cust] += 0.05 * r.principal * sig(base_u[r.cust])
    else:
        mat = r.open_date + pd.DateOffset(months=r.tenor_months)
        if r.open_date <= ad < mat:
            ex_debt[r.cust] += annuity(r.principal, r.interest_rate, r.tenor_months)
other_bank = np.where(rng.random(N) < np.where(is_ex, .35, .80),
                      income * rng.beta(2, 7, N) * 0.75 * np.exp(0.4 * z), 0)
ex_debt = np.round(ex_debt + other_bank, -3)

# Plafon sesuai kebijakan DSR (sebagian kecil pengecualian)
dsr_cap = rng.uniform(0.30, 0.70, N) + np.where(rng.random(N) < .08, .15, 0)
afford = np.maximum(dsr_cap * income - ex_debt, 0)
max_amt = principal_from_pmt(afford, rate, tenor)
amount = np.minimum(desired, max_amt)
min_amt = np.array([clip_amt[t][0] for t in loan_type]) * 0.6
amount = np.round(np.maximum(amount, min_amt), -5)
installment = np.round(annuity(amount, rate, tenor), -3)
dsr = (installment + ex_debt) / income
lti = amount / (income * 12)

# ------------------------------------------------------------------ 4. TRUE PD & DEFAULT
emp_c = pd.Series(emp).map({"Salaried": 0, "Business Owner": .2, "Self-employed": .5, "Contract": 1.0}).values
purp_c = pd.Series(loan_purpose).map({"Consumption": .1, "Education": 0, "Emergency": .45, "Renovation": -.05,
                                      "Debt Consolidation": .55, "Vehicle Purchase": -.1, "Home Purchase": -.3,
                                      "Working Capital": .15, "Business Expansion": .25}).values
chan_c = pd.Series(channel).map({"Branch": 0, "Online": .15, "Referral": -.1}).values
logit_wo_b = (5.5 * (dsr - 0.40) + emp_c + 0.5 * (ten < 12) + 0.3 * (age < 25) + 0.1 * (age > 55)
              - 0.6 * np.log(income / 9e6) + 0.10 * dependents + purp_c + chan_c
              + 0.2 * np.log1p(lti) + 0.85 * z)


def calibrate(lw, target):
    lo, hi = -15, 5
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if sig(lw + mid).mean() < target else (lo, mid)
    return mid


pd_true = np.zeros(N)
for grp, mask in [("existing", is_ex), ("new", ~is_ex)]:
    pd_true[mask] = sig(logit_wo_b[mask] + calibrate(logit_wo_b[mask], TARGET_PD[grp]))
default_draw = rng.random(N) < pd_true

# ------------------------------------------------------------------ 5. APP LOAN ACCOUNTS
disb = app_date + pd.to_timedelta(rng.integers(3, 15, N), unit="D")
app_id = np.array([f"APP{i:05d}" for i in range(1, N + 1)])
prod_from_type = {"Personal Loan": "Personal Loan", "Auto Loan": "Auto Loan", "Home Loan": "Home Loan",
                  "Business Loan": "Business Loan"}
app_acc = pd.DataFrame(dict(cust=np.arange(N), product_type=[prod_from_type[t] for t in loan_type],
                            open_date=disb, principal=amount, interest_rate=rate, tenor_months=tenor,
                            application_id=app_id))
acc = pd.concat([acc, app_acc], ignore_index=True)

# ------------------------------------------------------------------ 6. MONTHLY SIMULATION (existing)
ex = np.where(is_ex)[0]
n = len(ex)
k_app = month_idx(app_date[ex]).values if hasattr(month_idx(app_date[ex]), "values") else month_idx(app_date[ex])
k_app = np.asarray(k_app)
k_disb = np.asarray(month_idx(disb[ex]))
d_ex = default_draw[ex]
w = np.array([1, 2, 3, 4, 4, 4, 3, 2, 2, 1], float)
dm = k_disb + rng.choice(np.arange(3, 13), n, p=w / w.sum())
dm = np.where(d_ex, np.minimum(dm, k_disb + 12), 999)

base = 0.85 * z[ex] - 0.25
ar = np.zeros((n, T))
e = rng.normal(0, .3, (n, T))
for t in range(T):
    ar[:, t] = (0.8 * ar[:, t - 1] if t else 0) + e[:, t]
tt = np.arange(T)[None, :]
post = tt > k_app[:, None]
burden = post * 0.8 * (dsr[ex] - 0.4)[:, None]
ep = np.zeros((n, T))
has_ep = rng.random(n) < .30
st = rng.integers(0, T, n)
L = rng.integers(2, 7, n)
A = rng.uniform(.8, 2.2, n)
for i in np.where(has_ep)[0]:
    for t in range(st[i], min(T, st[i] + L[i])):
        pos = (t - st[i] + 1) / (L[i] + 1)
        ep[i, t] = A[i] * (1 - abs(2 * pos - 1))
ramp = np.array([.6, 1.2, 1.8, 2.4, 3.0, 3.5])
for i in np.where(d_ex)[0]:
    for t in range(max(0, dm[i] - 5), T):
        ep[i, t] = max(ep[i, t], ramp[min(t - (dm[i] - 5), 5)])
S = base[:, None] + ar + burden + ep

m = np.zeros(n, int)
DPD = np.zeros((n, T), int)
PR = np.zeros((n, T))
LATE = np.zeros((n, T), int)
MISS = np.zeros((n, T), int)
M = np.zeros((n, T), int)
for t in range(T):
    s = S[:, t]
    r = rng.random(n)
    p_miss, p_late = sig(-4.6 + 1.5 * s), sig(-2.9 + 1.45 * s)
    miss = r < p_miss
    late = (~miss) & (r < p_miss + p_late)
    forced = (t >= dm - 2) & (t > k_disb)
    miss = miss | forced
    late = late & ~forced
    cap = np.where(t <= k_app, 1, 2)
    over = (~forced) & (m + miss > cap)
    miss = miss & ~over
    defaulted_prev = m >= 3
    miss = miss | defaulted_prev
    late = late & ~miss
    cure = (~miss) & (m > 0) & (rng.random(n) < sig(0.8 - 0.9 * s))
    m_prev = m.copy()
    m = np.where(miss, m + 1, np.where(cure, 0, m))
    dpd = np.where(m > 0, 30 * m + rng.integers(0, 10, n), np.where(late, rng.integers(1, 30, n), 0))
    pr_norm = np.clip(rng.normal(1.0, .03, n) - .08 * np.maximum(s, 0), .75, 1.15)
    pr = np.select([miss & (m >= 3), miss, late, cure],
                   [rng.uniform(0, .1, n), rng.uniform(0, .5, n), rng.uniform(.5, .95, n),
                    np.minimum(1 + m_prev, 3) * rng.uniform(.95, 1.0, n)], pr_norm)
    DPD[:, t], PR[:, t], LATE[:, t], MISS[:, t], M[:, t] = dpd, pr, late, miss, m

# Default aktual = bulan pertama DPD >= 90
first_def = np.where((DPD >= 90).any(1), (DPD >= 90).argmax(1), 999)
lab_ex = ((first_def > k_disb) & (first_def <= k_disb + 12)).astype(int)
assert (lab_ex == d_ex).all(), "label existing tidak konsisten dengan DPD"
assert (first_def[~d_ex] == 999).all()

# Akun per bulan
acc["cust_ex_pos"] = acc.cust.map({c: p for p, c in enumerate(ex)})
U = sig(base_u[ex][:, None] + 1.0 * S + rng.normal(0, .12, (n, T)))
fdef_by_cust = dict(zip(ex, first_def))
fdef_by_cust.update({c: 999 for c in np.where(~is_ex)[0]})
OUTS = np.zeros((n, T)); LIM = np.zeros((n, T)); DUE = np.zeros((n, T)); NACT = np.zeros((n, T), int)
acc["close_date"] = pd.NaT
for r in acc.itertuples():
    oi = month_idx(r.open_date)
    if r.product_type == "Credit Card":
        close_i = 999
    else:
        mat = r.open_date + pd.DateOffset(months=r.tenor_months)
        fd = fdef_by_cust[r.cust]
        if mat <= DATA_END and month_idx(mat) < fd:
            acc.at[r.Index, "close_date"] = mat
            close_i = month_idx(mat)
        else:
            close_i = 999
    if np.isnan(r.cust_ex_pos):
        continue
    p = int(r.cust_ex_pos)
    for t in range(T):
        if MONTHS[t] < r.open_date or t >= close_i:
            continue
        NACT[p, t] += 1
        LIM[p, t] += r.principal
        if r.product_type == "Credit Card":
            o = r.principal * U[p, t]
            OUTS[p, t] += o
            DUE[p, t] += max(.05 * o, 5e4)
        else:
            paid_k = (MONTHS[t].year - r.open_date.year) * 12 + MONTHS[t].month - r.open_date.month
            if t >= fdef_by_cust[r.cust]:
                paid_k = min(paid_k, max(fdef_by_cust[r.cust] - 2 - oi, 0))
            OUTS[p, t] += balance_after(r.principal, r.interest_rate, r.tenor_months, paid_k)
            DUE[p, t] += annuity(r.principal, r.interest_rate, r.tenor_months)

overdue = np.where(M > 0, M * DUE, 0) + np.where(LATE == 1, DUE * (1 - np.minimum(PR, 1)), 0)
newacc = (rng.random((n, T)) < sig(-4.4 + 1.3 * S)).astype(int)
bucket = np.select([DPD == 0, DPD < 30, DPD < 60, DPD < 90], [0, 1, 2, 3], 4)
det = np.full((n, T), np.nan)
det[:, :-1] = (bucket[:, 1:] > bucket[:, :-1]).astype(float)
det[bucket == 4] = np.nan
d3 = np.full((n, T), np.nan)
for t in range(T - 3):
    d3[:, t] = (bucket[:, t + 1:t + 4] == 4).any(1)
d3[bucket == 4] = np.nan

df_m = pd.DataFrame({
    "customer_id": np.repeat(cust_id[ex], T),
    "snapshot_date": np.tile(MONTHS.strftime("%Y-%m-%d"), n),
    "total_outstanding": OUTS.ravel().round(0),
    "total_credit_limit": LIM.ravel().round(0),
    "credit_utilization": np.divide(OUTS, LIM, out=np.zeros_like(OUTS), where=LIM > 0).ravel().round(4),
    "total_monthly_payment": (DUE * np.minimum(PR, 3)).ravel().round(0),
    "total_amount_due": DUE.ravel().round(0),
    "payment_ratio": PR.ravel().round(4),
    "dpd": DPD.ravel(),
    "late_payment_count": pd.DataFrame(LATE.T).rolling(6, 1).sum().T.values.ravel().astype(int),
    "missed_payment_count": pd.DataFrame(MISS.T).rolling(6, 1).sum().T.values.ravel().astype(int),
    "overdue_amount": overdue.ravel().round(0),
    "active_accounts": NACT.ravel(),
    "new_credit_accounts": newacc.ravel(),
})
g = df_m.groupby("customer_id", sort=False)
df_m["outstanding_change_1m"] = g.total_outstanding.pct_change().fillna(0).replace([np.inf, -np.inf], 0).round(4)
df_m["payment_ratio_change_1m"] = g.payment_ratio.diff().fillna(0).round(4)
df_m["max_dpd_3m"] = g.dpd.transform(lambda s: s.rolling(3, 1).max()).astype(int)
df_m["avg_utilization_3m"] = g.credit_utilization.transform(lambda s: s.rolling(3, 1).mean()).round(4)
df_m["deterioration_next_1m"] = det.ravel()
df_m["default_next_3m"] = d3.ravel()

# ------------------------------------------------------------------ 7. NEW APPLICANT OUTCOMES
nw = np.where(~is_ex)[0]
d_new = default_draw[nw]
dm_rel = rng.choice(np.arange(3, 13), len(nw), p=w / w.sum())
months_obs = np.asarray(month_idx(DATA_END)) - np.asarray(month_idx(disb[nw]))
final_dpd_new = np.where(
    d_new, 90 + 30 * np.maximum(months_obs - dm_rel, 0) + rng.integers(0, 10, len(nw)),
    np.select([rng.random(len(nw)) < sig(-3.2 + .8 * z[nw]), rng.random(len(nw)) < sig(-2.2 + .8 * z[nw])],
              [30 + 30 * rng.integers(0, 2, len(nw)) + rng.integers(0, 10, len(nw)), rng.integers(1, 30, len(nw))], 0))
final_dpd = np.zeros(N, int)
final_dpd[ex] = DPD[:, -1]
final_dpd[nw] = final_dpd_new
for c, d, dr, kd in zip(nw, d_new, dm_rel, np.asarray(month_idx(disb[nw]))):
    fdef_by_cust[c] = kd + dr if d else 999
# tutup pinjaman new yang jatuh tempo & tidak default
for r in acc[acc.cust.isin(nw)].itertuples():
    mat = r.open_date + pd.DateOffset(months=r.tenor_months)
    ok = mat <= DATA_END and month_idx(mat) < fdef_by_cust[r.cust]
    acc.at[r.Index, "close_date"] = mat if ok else pd.NaT

default_label = np.zeros(N, int)
default_label[ex] = lab_ex
default_label[nw] = d_new.astype(int)

# ------------------------------------------------------------------ 8. CREDIT ACCOUNT TABLE
acc = acc.sort_values(["open_date", "cust"]).reset_index(drop=True)
closed = acc.close_date.notna()
cd = final_dpd[acc.cust.values]
acc_status = np.where(closed, "Closed", np.select([cd >= 90, cd >= 30], ["Default", "Delinquent"], "Active"))
# outstanding akhir
out_end = np.zeros(len(acc))
cc_util_end = sig(base_u + 0.8 * 0)  # default utilisasi
for r in acc.itertuples():
    if closed[r.Index]:
        continue
    if r.product_type == "Credit Card":
        p = r.cust_ex_pos
        out_end[r.Index] = r.principal * (U[int(p), -1] if not np.isnan(p) else cc_util_end[r.cust])
    else:
        k = (DATA_END.year - r.open_date.year) * 12 + DATA_END.month - r.open_date.month
        fd = fdef_by_cust[r.cust]
        if fd < 999:
            k = min(k, max(fd - 2 - month_idx(r.open_date), 0))
        out_end[r.Index] = balance_after(r.principal, r.interest_rate, r.tenor_months, k)
inst = np.where(acc.product_type == "Credit Card", np.maximum(.05 * out_end, np.where(closed, 0, 5e4)),
                annuity(acc.principal, acc.interest_rate, acc.tenor_months.replace(0, 1)))
df_acc = pd.DataFrame({
    "account_id": [f"ACC{i:05d}" for i in range(1, len(acc) + 1)],
    "customer_id": cust_id[acc.cust.values],
    "application_id": acc.application_id.values,
    "product_type": acc.product_type.values,
    "open_date": acc.open_date.dt.strftime("%Y-%m-%d").values,
    "close_date": acc.close_date.dt.strftime("%Y-%m-%d").values,
    "credit_limit": acc.principal.round(0).values,
    "outstanding": np.round(out_end, 0),
    "interest_rate": acc.interest_rate.values,
    "tenor_months": acc.tenor_months.values,
    "monthly_installment": np.round(inst, -3),
    "account_status": acc_status,
    "days_past_due": np.where(closed, 0, cd),
})

# ------------------------------------------------------------------ 9. CUSTOMER PROFILE & APPLICATION TABLES
first_open = acc.groupby("cust").open_date.min()
cust_since = np.empty(N, dtype=object)
for i in range(N):
    if is_ex[i]:
        cust_since[i] = (first_open[i] - pd.Timedelta(days=int(rng.integers(0, 400)))).strftime("%Y-%m-%d")
    else:
        cust_since[i] = disb[i].strftime("%Y-%m-%d")
df_cp = pd.DataFrame(dict(customer_id=cust_id, customer_status=status, age=age, gender=gender,
                          marital_status=marital, dependents=dependents, employment_type=emp,
                          employment_tenure_months=ten, monthly_income=income, income_source=income_source,
                          customer_since=cust_since, city=city, customer_segment=segment))
df_app = pd.DataFrame(dict(application_id=app_id, customer_id=cust_id, customer_status=status,
                           application_date=app_date.strftime("%Y-%m-%d"), loan_type=loan_type,
                           loan_purpose=loan_purpose, requested_amount=amount, tenor_months=tenor,
                           interest_rate=rate, monthly_installment=installment, existing_monthly_debt=ex_debt,
                           application_channel=channel, disbursement_date=disb.strftime("%Y-%m-%d"),
                           default_12m=default_label))

# ------------------------------------------------------------------ 10. INTERVIEW (new applicants)
zn = z[nw]
q = lambda x, p: np.quantile(x, p)
# income trend
tr_s = -0.8 * zn + rng.normal(0, .6, len(nw))
vol_s = 1.0 * np.isin(emp[nw], ["Business Owner", "Self-employed", "Contract"]) + .5 * zn + rng.normal(0, 1, len(nw))
income_trend = np.select([tr_s < q(tr_s, .2), tr_s > q(tr_s, .8)], ["declining", "increasing"], "stable").astype(object)
income_trend[vol_s >= q(vol_s, .9)] = "volatile"
# income stability
emp_stab = pd.Series(emp[nw]).map({"Salaried": .8, "Contract": -.8, "Business Owner": 0, "Self-employed": -.3}).values
st_s = emp_stab + .6 * np.minimum(ten[nw], 60) / 60 - .6 * zn + rng.normal(0, .5, len(nw))
income_stability = np.select([st_s < q(st_s, .10), st_s < q(st_s, .50)], ["low", "medium"], "high")
# debt level (self-report dari kewajiban aktual, ada understatement)
dr = ex_debt[nw] / income[nw]
lvl = np.select([dr == 0, dr < .12, dr < .25], [0, 1, 2], 3)
lvl = np.where((rng.random(len(nw)) < .12) & (lvl > 0), lvl - 1, lvl)
existing_debt_level = np.array(["none", "low", "medium", "high"])[lvl]
# repayment issue (riwayat di lembaga lain)
rp_s = .9 * zn + rng.normal(0, .6, len(nw))
repayment_issue = np.select([rp_s < q(rp_s, .6), rp_s < q(rp_s, .9)], ["none", "occasional"], "frequent")
# financial change
is_bizn = biz[nw] | np.isin(income_source[nw], ["Business", "Mixed"])
fc_s = .8 * zn + rng.normal(0, .7, len(nw))
changed = fc_s >= q(fc_s, .5)
pick = rng.random(len(nw))
financial_change = np.where(~changed, "stable",
                            np.where(is_bizn, np.select([pick < .55, pick < .78], ["business_decline", "income_decrease"], "expense_increase"),
                                     np.where(pick < .5, "income_decrease", "expense_increase")))
# business condition
bc_s = -.8 * zn + rng.normal(0, .6, len(nw))
bq25, bq65 = q(bc_s[is_bizn], .25), q(bc_s[is_bizn], .65)
business_condition = np.where(~is_bizn, "not_applicable",
                              np.select([bc_s < bq25, bc_s < bq65], ["declining", "stable"], "growing"))

QUESTIONS = {
    "Q01": "Bagaimana kondisi pendapatan Anda dalam beberapa bulan terakhir?",
    "Q02": "Apakah saat ini Anda memiliki cicilan atau kewajiban kredit lain?",
    "Q03": "Bagaimana riwayat pembayaran cicilan Anda sebelumnya?",
    "Q04": "Apakah ada perubahan kondisi keuangan akhir-akhir ini?",
    "Q05": "Apa tujuan utama pengajuan kredit?",
    "Q06": "Bagaimana kondisi usaha atau pekerjaan Anda saat ini?",
}


def rp(x):
    x = max(x, 1e5)
    jt = x / 1e6
    style = rng.integers(0, 4)
    if style == 0:
        return f"{jt:.1f}".replace(".", ",").replace(",0", "") + " juta"
    if style == 1:
        return f"Rp{int(round(x, -5)):,}".replace(",", ".")
    if style == 2:
        return f"{jt:.1f}".replace(".", ",").replace(",0", "") + "jt"
    return f"{round(jt):.0f} juta-an"


def pick1(lst):
    return lst[rng.integers(0, len(lst))]


OPEN = ["", "", "", "Hmm, ", "Jujur ya, ", "Kalau itu, ", "Oke, ", "Begini, ", "Ya, "]
JOB = {"Salaried": "kantor", "Contract": "kerja kontrak", "Business Owner": "usaha", "Self-employed": "kerjaan freelance"}


def join_open(o, a):
    return a if not o else o + (a[0].lower() + a[1:] if not a.startswith("Rp") else a)


def informal(s):
    if rng.random() < .35:
        s = (s.replace("tidak ", pick1(["nggak ", "gak ", "ga "])).replace("Tidak ", pick1(["Nggak ", "Gak "]))
             .replace("sekitar ", pick1(["sekitar ", "kira-kira ", "kurang lebih "])).replace("sudah ", "udah "))
    return s


def a_q01(i, tr, stab):
    inc_s = income[i] * rng.normal(1, .08)
    src = JOB[emp[i]]
    d = {
        "stable": [f"Pendapatan saya relatif stabil, sekitar {rp(inc_s)} per bulan.",
                   f"Penghasilan dari {src} masuk rutin tiap bulan, kurang lebih {rp(inc_s)}.",
                   f"Tidak banyak berubah, masih di kisaran {rp(inc_s)} sebulan.",
                   f"Aman sih, tiap bulan dapat sekitar {rp(inc_s)} dari {src}."],
        "increasing": [f"Alhamdulillah ada kenaikan, sekarang sekitar {rp(inc_s)}, sebelumnya {rp(inc_s * rng.uniform(.75, .9))}.",
                       f"Naik lumayan sejak {pick1(['dapat promosi', 'kenaikan gaji tahunan', 'usaha makin ramai', 'dapat proyek baru', 'pindah kerja'])}, sekarang {rp(inc_s)} per bulan.",
                       f"Tren pendapatan saya membaik, sekarang di angka {rp(inc_s)}."],
        "declining": [f"Agak turun beberapa bulan terakhir, dari sekitar {rp(inc_s * rng.uniform(1.15, 1.4))} jadi {rp(inc_s)}.",
                      f"Menurun karena {pick1(['lembur dikurangi', 'komisi turun', 'orderan sepi', 'tunjangan dipotong', 'jam kerja dikurangi'])}, sekarang sekitar {rp(inc_s)}.",
                      f"Jujur lagi turun, sekarang cuma {rp(inc_s)} sebulan."],
        "volatile": [f"Naik turun, tergantung {pick1(['proyek', 'musim', 'orderan', 'jumlah klien'])}. Kadang {rp(inc_s * .5)}, kadang bisa {rp(inc_s * 1.6)}.",
                     f"Tidak tentu tiap bulan, rata-rata mungkin {rp(inc_s)} tapi fluktuatif banget.",
                     f"Pendapatan saya tidak menentu, ada bulan bagus ada bulan sepi sekali."],
    }
    s = pick1(d[tr])
    add = {
        "high": [f" Saya sudah {max(ten[i] // 12, 1)} tahun di {src} ini.", " Posisi saya cukup aman.", ""],
        "medium": [" Cukup aman, walaupun belum bisa dibilang pasti.", "", " Sejauh ini masih lancar."],
        "low": [f" Tapi {pick1(['kontrak saya tinggal beberapa bulan', 'belum ada pemasukan tetap', 'kantor lagi ada pengurangan karyawan', 'pemasukan tergantung pesanan'])}.",
                " Terus terang belum terlalu pasti ke depannya."],
    }
    return s + pick1(add[stab])


def a_q02(i, lvl_):
    debt = ex_debt[i] * rng.normal(1, .1)
    items = ["kartu kredit", "cicilan motor", "paylater", "KTA bank lain", "cicilan HP", "pinjaman koperasi", "cicilan mobil"]
    d = {
        "none": ["Tidak ada cicilan lain saat ini.", "Saat ini saya bebas cicilan.", "Belum punya pinjaman di tempat lain."],
        "low": [f"Ada cicilan kecil, {pick1(items)} sekitar {rp(debt)} per bulan.", f"Cuma {pick1(items)}, sebulan {rp(debt)}."],
        "medium": [f"Ada {rng.integers(2, 3)} cicilan, {pick1(items)} dan {pick1(items)}, totalnya kira-kira {rp(debt)} sebulan.",
                   f"Lumayan ada beberapa, total sekitar {rp(debt)} per bulan."],
        "high": [f"Cukup banyak, ada {pick1(items)}, {pick1(items)}, sama {pick1(items)}. Total hampir {rp(debt)} per bulan.",
                 f"Jujur cicilan saya lumayan berat, sekitar {rp(debt)} tiap bulan.",
                 f"Ada beberapa pinjaman, kalau ditotal {rp(debt)} sebulan."],
    }
    return pick1(d[lvl_])


def a_q03(i, rep):
    d = {
        "none": ["Selama ini selalu bayar tepat waktu.", "Tidak pernah telat, biasanya autodebet.", "Lancar terus, belum pernah nunggak."],
        "occasional": [f"Pernah telat beberapa kali, biasanya cuma {rng.integers(3, 15)} hari karena {pick1(['gajian mundur', 'lupa transfer', 'ada keperluan mendadak', 'pembayaran dari klien telat'])}.",
                       "Sesekali telat sedikit, tapi selalu saya lunasi.",
                       "Ada satu-dua kali terlambat tahun lalu, sekarang sudah normal."],
        "frequent": [f"Jujur cukup sering telat, bahkan pernah nunggak {rng.integers(1, 4)} bulan di {pick1(['bank lain', 'paylater', 'koperasi', 'leasing'])}.",
                     "Beberapa bulan terakhir sering terlambat karena keuangan lagi seret.",
                     "Pernah ditagih debt collector karena telat bayar kartu kredit."],
    }
    return pick1(d[rep])


def a_q04(i, fc):
    d = {
        "stable": ["Tidak ada perubahan berarti.", "Kondisi keuangan masih sama seperti sebelumnya.", "Sejauh ini stabil, tidak ada kejadian besar."],
        "income_decrease": [f"Penghasilan berkurang karena {pick1(['pasangan berhenti kerja', 'bonus tidak cair', 'lembur dihapus', 'komisi turun', 'pindah ke posisi dengan gaji lebih kecil'])}.",
                            "Pemasukan rumah tangga turun dibanding tahun lalu."],
        "expense_increase": [f"Pengeluaran naik, {pick1(['anak mulai masuk sekolah', 'biaya berobat orang tua', 'sewa rumah naik', 'baru punya anak', 'harga kebutuhan pokok naik'])}.",
                             "Kebutuhan bulanan makin besar, jadi lebih ketat."],
        "business_decline": [f"Usaha lagi lesu, omzet turun sekitar {rng.integers(15, 50)}% dibanding tahun lalu.",
                             f"Penjualan menurun sejak {pick1(['ada kompetitor baru', 'daya beli turun', 'supplier naik harga', 'lokasi sepi'])}."],
    }
    return pick1(d[fc])


def a_q05(i):
    p = loan_purpose[i]
    d = {
        "Consumption": ["Untuk kebutuhan konsumsi, beli perabot dan elektronik.", "Buat keperluan pribadi, rencana pernikahan.", "Untuk biaya liburan keluarga dan kebutuhan rumah tangga."],
        "Education": ["Untuk biaya kuliah anak.", "Bayar uang pangkal sekolah anak.", "Biaya S2 saya."],
        "Emergency": ["Ada kebutuhan mendadak, biaya rumah sakit keluarga.", "Untuk keperluan darurat, perbaikan rumah karena banjir.", "Butuh dana cepat untuk kebutuhan mendesak."],
        "Renovation": ["Untuk renovasi rumah, atap dan dapur.", "Mau perbaiki dan tambah kamar di rumah."],
        "Debt Consolidation": ["Untuk melunasi beberapa cicilan lain supaya jadi satu.", "Mau menutup utang kartu kredit dan paylater."],
        "Vehicle Purchase": ["Untuk beli mobil keluarga.", "Beli kendaraan untuk operasional kerja."],
        "Home Purchase": ["Untuk beli rumah pertama.", "Ambil KPR rumah dekat kantor."],
        "Working Capital": ["Tambahan modal kerja untuk stok barang.", "Untuk perputaran modal usaha."],
        "Business Expansion": ["Mau buka cabang baru.", "Untuk beli mesin dan menambah kapasitas produksi."],
    }
    return pick1(d[p])


def a_q06(i, bc):
    if bc == "not_applicable":
        e_ = emp[i]
        if e_ == "Contract":
            return pick1(["Kerja kontrak, sejauh ini diperpanjang terus.", "Masih kontrak, perpanjangan berikutnya belum pasti.", "Kerjaan lancar, tapi statusnya masih kontrak."])
        return pick1(["Pekerjaan saya stabil, kantor juga sehat.", "Masih aman, tidak ada isu PHK.", "Lancar, beban kerja normal.", "Baik, baru saja dapat penilaian kinerja bagus."])
    d = {
        "growing": ["Usaha sedang berkembang, pelanggan bertambah.", f"Alhamdulillah ramai, omzet naik sekitar {rng.integers(10, 40)}%.", "Bagus, baru dapat kontrak dengan klien besar."],
        "stable": ["Usaha jalan normal, tidak naik tidak turun.", "Stabil, pelanggan tetap masih ada.", "Biasa saja, cukup untuk operasional."],
        "declining": ["Usaha sedang menurun, pelanggan berkurang.", "Lagi sepi, beberapa karyawan terpaksa dikurangi.", f"Kurang bagus, penjualan turun hampir {rng.integers(20, 60)}%."],
    }
    return pick1(d[bc])


rows = []
for k, i in enumerate(nw):
    iid = f"INT{k + 1:05d}"
    idate = (app_date[i] - pd.Timedelta(days=int(rng.integers(0, 8)))).strftime("%Y-%m-%d")
    labels = dict(income_trend=income_trend[k], income_stability=income_stability[k],
                  existing_debt_level=existing_debt_level[k], repayment_issue=repayment_issue[k],
                  financial_change=financial_change[k], business_condition=business_condition[k])
    ans = {"Q01": a_q01(i, income_trend[k], income_stability[k]), "Q02": a_q02(i, existing_debt_level[k]),
           "Q03": a_q03(i, repayment_issue[k]), "Q04": a_q04(i, financial_change[k]), "Q05": a_q05(i),
           "Q06": a_q06(i, business_condition[k])}
    for qid, qtext in QUESTIONS.items():
        rows.append(dict(interview_id=iid, application_id=app_id[i], question_id=qid, question=qtext,
                         response_text=informal(join_open(pick1(OPEN), ans[qid])), interview_date=idate, **labels))
df_iv = pd.DataFrame(rows)

# ------------------------------------------------------------------ 11. SAVE
df_cp.to_csv(OUT / "customer_profile.csv", index=False)
df_app.to_csv(OUT / "credit_application.csv", index=False)
df_acc.to_csv(OUT / "credit_account.csv", index=False)
df_iv.to_csv(OUT / "applicant_interview.csv", index=False)
df_m.to_csv(OUT / "monthly_behavior.csv", index=False)


def pct(s):
    return (s.value_counts(normalize=True) * 100).round(2).to_dict()


summary = {
    "version": "v4", "seed": SEED,
    "rows": {"customer_profile.csv": len(df_cp), "credit_application.csv": len(df_app),
             "applicant_interview.csv": len(df_iv), "credit_account.csv": len(df_acc),
             "monthly_behavior.csv": len(df_m)},
    "customer_status_pct": pct(df_cp.customer_status),
    "employment_type_pct": pct(df_cp.employment_type),
    "customer_segment_pct": pct(df_cp.customer_segment),
    "loan_type_pct": pct(df_app.loan_type),
    "loan_purpose_pct": pct(df_app.loan_purpose),
    "account_status_pct": pct(df_acc.account_status),
    "application_default_12m_pct": {"all": round(df_app.default_12m.mean() * 100, 2),
                                     **{k: round(v * 100, 2) for k, v in df_app.groupby("customer_status").default_12m.mean().items()}},
    "monthly_deterioration_next_1m_pct": round(df_m.deterioration_next_1m.mean() * 100, 2),
    "monthly_default_next_3m_pct": round(df_m.default_next_3m.mean() * 100, 2),
    "interview": {c: pct(df_iv.drop_duplicates("interview_id")[c]) for c in
                  ["income_trend", "income_stability", "existing_debt_level", "repayment_issue", "financial_change", "business_condition"]},
    "interview_unique_responses": int(df_iv.response_text.nunique()),
}
(OUT / "distribution_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False))
print(json.dumps(summary, indent=2, ensure_ascii=False))
