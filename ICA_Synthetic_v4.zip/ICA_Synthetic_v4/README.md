# ICA Synthetic Dataset v4

Dataset sintetis untuk project **ICA (Intelligent Credit Analyst)**. Semua tabel di-generate dari satu
variabel laten per nasabah (tekanan finansial tersembunyi, tidak diekspor). Akibatnya profil, jawaban
interview, perilaku bayar bulanan, DPD, dan label saling konsisten. Generator: `generate_ica_data.py` (seed 42).

## Tabel dan relasi

```
customer_profile (12.000) ──1:1── credit_application (12.000) ──1:1── credit_account (pinjaman hasil aplikasi)
        │                                   │
        ├──1:N── credit_account (akun lama nasabah existing, dibuka sebelum 2024)
        ├──1:24─ monthly_behavior (hanya existing, Jan 2024 – Des 2025)
        └─────── applicant_interview (hanya new applicant, 6 baris per interview)
```

| File | Baris | Kunci | Isi |
|---|---|---|---|
| customer_profile.csv | 12.000 | customer_id | Demografi, pekerjaan, penghasilan. 8.000 existing, 4.000 new |
| credit_application.csv | 12.000 | application_id | Aplikasi yang disetujui dan dicairkan, beserta **label Credit Risk** |
| credit_account.csv | ±22.000 | account_id | Semua akun: akun lama nasabah existing + pinjaman hasil aplikasi (existing dan new) |
| applicant_interview.csv | 24.000 | interview_id + question_id | Interview new applicant: 6 pertanyaan, jawaban bahasa natural, dan label ekstraksi |
| monthly_behavior.csv | 192.000 | customer_id + snapshot_date | Snapshot akhir bulan nasabah existing, beserta **label Early Warning** |

## Definisi label

| Label | Tabel | Definisi | Rate |
|---|---|---|---|
| `default_12m` | credit_application | 1 jika **DPD ≥ 90 hari (kolektibilitas 3–5 OJK)** terjadi dalam **12 bulan setelah pencairan** | 9,7% (existing 8,7%, new 11,7%) |
| `deterioration_next_1m` | monthly_behavior | 1 jika **bucket DPD bulan depan lebih buruk** dari bulan ini. Bucket: 0 / 1–29 / 30–59 / 60–89 / 90+ | ±9,3% |
| `default_next_3m` | monthly_behavior | 1 jika DPD ≥ 90 tercapai dalam 3 bulan ke depan (label tambahan, opsional) | ±1,3% |

Label monthly bernilai **NaN** jika nasabah sudah default (DPD ≥ 90, tidak relevan untuk early warning)
atau jendela masa depannya melewati Des 2025.

**Konsistensi yang dijamin generator:**
- Semua aplikasi `default_12m = 1` punya akun hasil aplikasi berstatus `Default` dengan `days_past_due ≥ 90`. Semua yang `default_12m = 0` tidak pernah mencapai DPD 90.
- Untuk existing, label diturunkan langsung dari jejak DPD di `monthly_behavior`.
- Default selalu didahului deteriorasi: DPD bergerak 30 → 60 → 90, dan beberapa bulan sebelumnya utilisasi naik serta payment ratio turun.

## Timeline dan aturan point-in-time (penting untuk mencegah leakage)

- `monthly_behavior`: 24 snapshot, 2024-01-31 s.d. 2025-12-31.
- `application_date`: Jul–Des 2024. `disbursement_date` = aplikasi + 3–14 hari.
- Jendela performa 12 bulan setelah pencairan semuanya berakhir paling lambat Des 2025.
- **Fitur Credit Risk existing hanya boleh diambil dari snapshot dengan `snapshot_date < application_date`.**
- Kolom `credit_account` (`days_past_due`, `account_status`, `outstanding`) adalah kondisi per **2025-12-31**, jadi **hasil**, bukan fitur. Jangan dipakai untuk training Credit Risk. Tabel ini untuk tools Agentic AI (read-only).
- `customer_status` = status **saat aplikasi**. Untuk new applicant, `customer_since` = tanggal pencairan.

## Kamus kolom

### customer_profile
| Kolom | Keterangan |
|---|---|
| customer_status | `existing` (sudah punya akun sebelum aplikasi) / `new` |
| employment_type | Salaried, Business Owner, Self-employed, Contract |
| employment_tenure_months | Lama bekerja/berusaha (bulan) |
| monthly_income | Penghasilan bulanan (Rp) |
| income_source | Salary, Business, Mixed |
| customer_segment | Mass (< 9 jt), Upper Mass (9–25 jt), Affluent (≥ 25 jt). Diturunkan dari penghasilan |

### credit_application
| Kolom | Keterangan |
|---|---|
| loan_type | Personal, Auto, Home, Business Loan |
| loan_purpose | Konsisten dengan loan_type (Auto → Vehicle Purchase, Home → Home Purchase/Renovation, Business → Working Capital/Business Expansion, Personal → Consumption/Education/Emergency/Renovation/Debt Consolidation) |
| requested_amount, tenor_months, interest_rate | Plafon (Rp), tenor (bulan), bunga efektif tahunan (%) |
| monthly_installment | Cicilan anuitas pinjaman baru (Rp) |
| existing_monthly_debt | Total cicilan existing di semua lembaga (setara SLIK) saat aplikasi (Rp) |
| application_channel | Branch, Online, Referral |
| disbursement_date | Tanggal pencairan |
| default_12m | **Label Credit Risk** |

DSR = (monthly_installment + existing_monthly_debt) / monthly_income. Plafon dibatasi kebijakan DSR 30–70%
dengan sekitar 8% pengecualian.

### credit_account
| Kolom | Keterangan |
|---|---|
| application_id | Terisi jika akun berasal dari aplikasi di credit_application; kosong untuk akun lama |
| product_type | Credit Card, Personal, Auto, Home, Business Loan |
| credit_limit | Limit kartu atau pokok awal pinjaman |
| tenor_months | 0 = revolving (kartu kredit) |
| account_status | Active (DPD < 30), Delinquent (30–89), Default (≥ 90), Closed (lunas/jatuh tempo) |
| days_past_due | DPD per 2025-12-31 |

### applicant_interview
Enam pertanyaan per interview (Q01–Q06), jawaban bahasa Indonesia natural: variasi kalimat, angka nominal,
gaya informal, sekitar 7.800 kalimat unik. Kolom label ekstraksi bernilai sama di semua baris interview yang
sama dan menjadi **ground truth untuk mengevaluasi ekstraksi GenAI**.

| Pertanyaan | Label | Nilai |
|---|---|---|
| Q01 Pendapatan | income_trend, income_stability | stable/increasing/declining/volatile; high/medium/low |
| Q02 Cicilan lain | existing_debt_level | none/low/medium/high. Self-report rasio cicilan existing terhadap penghasilan (< 12%, 12–25%, > 25%); sekitar 12% responden menyebut level lebih rendah dari kenyataan |
| Q03 Riwayat bayar | repayment_issue | none/occasional/frequent |
| Q04 Perubahan keuangan | financial_change | stable/income_decrease/expense_increase/business_decline (yang terakhir hanya untuk nasabah berusaha) |
| Q05 Tujuan | – | Konsisten dengan loan_purpose di aplikasi |
| Q06 Usaha/pekerjaan | business_condition | growing/stable/declining; not_applicable untuk karyawan |

Karena `existing_debt_level` adalah self-report, nilainya bisa dicocokkan dengan `existing_monthly_debt` di
aplikasi. Ini contoh bagus untuk cross-check oleh Agentic AI.

### monthly_behavior
| Kolom | Keterangan |
|---|---|
| total_outstanding, total_credit_limit | Total baki debet dan limit seluruh akun aktif di bank |
| credit_utilization | outstanding / limit |
| total_amount_due | Total tagihan jatuh tempo bulan itu |
| total_monthly_payment | Nominal yang dibayar bulan itu |
| payment_ratio | Dibayar / tagihan (> 1 berarti melunasi tunggakan) |
| dpd | Days past due saat snapshot |
| late_payment_count, missed_payment_count | Jumlah bayar telat / tidak bayar dalam 6 bulan terakhir |
| overdue_amount | Nominal tunggakan |
| active_accounts | Jumlah akun aktif di bank |
| new_credit_accounts | Akun kredit baru di lembaga lain bulan itu (sinyal SLIK, *credit hungry*) |
| outstanding_change_1m, payment_ratio_change_1m | Perubahan 1 bulan |
| max_dpd_3m, avg_utilization_3m | Agregat 3 bulan terakhir |

## Arah sinyal (sudah divalidasi)

- **Risiko naik**: DSR tinggi, pekerjaan Contract atau Self-employed, masa kerja < 12 bulan, penghasilan rendah, tujuan Emergency/Debt Consolidation, jawaban interview negatif (pendapatan menurun/volatile, stabilitas rendah, sering telat bayar, usaha menurun).
- **Tidak berpengaruh** (sengaja, untuk fairness): gender, kota, status pernikahan.
- **Baseline sanity check** (GBM default, tanpa feature engineering, AUC):
  - Credit Risk new, aplikasi saja ≈ 0,75; ditambah interview ≈ 0,80
  - Credit Risk existing, aplikasi saja ≈ 0,76; ditambah perilaku sebelum aplikasi ≈ 0,79
  - Early Warning `deterioration_next_1m` ≈ 0,77

  Masih ada ruang untuk feature engineering, misalnya tren, delta, dan rolling window.

## Simplifikasi yang perlu diketahui

- Dataset hanya berisi aplikasi yang disetujui (tidak ada reject inference). Kolom `application_status` dihapus.
- DPD dihitung di level nasabah: semua akun aktif seorang nasabah berbagi DPD yang sama.
- Nasabah new tidak punya `monthly_behavior` setelah pencairan. Hasil akhirnya hanya terlihat di `credit_account`.

## Perubahan dari v3

| v3 | v4 |
|---|---|
| `credit_application.default_next_3m` | `default_12m` (definisi DPD 90+ / 12 bulan, bisa dilacak ke DPD) |
| `application_status` | Dihapus (semua aplikasi disetujui) |
| – | Ditambah: `interest_rate`, `disbursement_date` (aplikasi), `total_amount_due` (monthly) |
| account_status Active/Closed/Delinquent | + `Default` |
| Akun hanya untuk existing | Pinjaman hasil aplikasi new applicant juga tercatat |
| Jawaban interview 44 template | ±7.800 kalimat unik |
| Label interview kosong per pertanyaan | Terisi di semua baris (label level interview) |
