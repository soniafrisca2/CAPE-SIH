---
doc_id: FAQ-ANALIS
judul: FAQ Analis Kredit tentang ICA
jenis: faq
versi: 1.0
berlaku: 2026-06-01
pemilik: Divisi Manajemen Risiko Kredit
bank: Bank Sentosa Raya (fiktif)
---

# FAQ Analis Kredit tentang ICA

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Apakah analis boleh menolak pengajuan walaupun ICA merekomendasikan Approve?

Boleh. Keputusan berbeda dari rekomendasi ICA dicatat sebagai override dengan kode yang sesuai (lihat SOP-ANALISA Bagian 6) dan alasan tertulis.

## Apa beda skor risiko dan PD terkalibrasi?

Skor risiko adalah keluaran mentah model yang dibandingkan dengan threshold untuk menentukan rekomendasi. PD terkalibrasi adalah perkiraan peluang gagal bayar dalam 12 bulan yang sudah disesuaikan dengan tingkat gagal bayar historis. Untuk menjelaskan risiko kepada pemegang kewenangan, gunakan PD terkalibrasi.

## Mengapa ICA tidak menampilkan Early Warning untuk pemohon baru?

Early Warning membutuhkan riwayat pembayaran bulanan di bank. Pemohon baru belum memiliki riwayat tersebut, sehingga ICA hanya menampilkan Credit Risk.

## Siapa yang menetapkan threshold ICA?

Threshold ditetapkan oleh Komite Manajemen Risiko berdasarkan kebijakan *recall-first* (minimal 70% calon gagal bayar tertangkap pada data validasi) dan ditinjau setiap kuartal.

## Apa arti zona Further Review?

Skor yang berada dalam rentang ±0,05 dari threshold, atau input yang di luar rentang data latih model, tidak diputuskan otomatis dan diarahkan ke Further Review.

## Bagaimana jika data di ICA berbeda dengan dokumen pemohon?

Gunakan data dari dokumen yang sudah diverifikasi, perbaiki input di form, dan bila keputusan berbeda dengan rekomendasi gunakan kode override OVR-05.

## Apakah ICA boleh dipakai untuk pemohon kredit korporasi?

Tidak. ICA hanya dikalibrasi untuk kredit konsumer dan KMK usaha kecil. Kredit korporasi dianalisa dengan metodologi kredit komersial.

## Berapa lama transkrip interview disimpan?

Transkrip interview disimpan 5 tahun sesuai SOP-INTERVIEW Bagian 6.
