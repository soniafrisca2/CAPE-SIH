---
doc_id: PB-EW
judul: Playbook Penanganan Early Warning
jenis: playbook
versi: 1.4
berlaku: 2026-05-01
pemilik: Divisi Collection & Recovery
bank: Bank Sentosa Raya (fiktif)
---

# Playbook Penanganan Early Warning

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Tujuan

Playbook ini mengatur tindakan terhadap nasabah existing yang mendapat status **ALERT** dari model Early Warning ICA (peluang kondisi pembayaran memburuk bulan depan di atas threshold), serta nasabah yang sudah menunggak.

## Bagian 2 Tindakan per Kondisi

| Kondisi nasabah | Tindakan | Waktu |
|---|---|---|
| ALERT, DPD 0 (belum menunggak) | pengingat WhatsApp/SMS H-3 sebelum jatuh tempo dan telepon *soft reminder* | maksimal 2 hari kerja sejak alert |
| DPD 1–30 | *desk call* oleh tim collection | hari ke-3 dan hari ke-7 setelah jatuh tempo |
| DPD 31–60 | Surat Peringatan 1 (SP1) dan kunjungan lapangan | paling lambat DPD 35 |
| DPD 61–90 | Surat Peringatan 2 (SP2) dan asesmen kelayakan restrukturisasi | paling lambat DPD 65 |
| DPD di atas 90 | pengalihan ke Unit Remedial | paling lambat DPD 95 |

## Bagian 3 SLA Tindak Lanjut Alert

Setiap alert Early Warning wajib ditindaklanjuti **paling lambat 2 hari kerja** sejak alert terbit. Hasil kontak dicatat dengan kode hasil:

- **PTP** (*promise to pay*): nasabah berjanji membayar pada tanggal tertentu;
- **RTP** (*refuse to pay*): nasabah menolak membayar;
- **NC** (*no contact*): nasabah tidak dapat dihubungi;
- **RS** (*request restructuring*): nasabah meminta restrukturisasi.

## Bagian 4 Alert Berulang

Nasabah yang mendapat ALERT **3 bulan berturut-turut** wajib ditinjau limitnya. Untuk kartu kredit, limit yang belum terpakai dapat dibekukan sementara. Untuk kredit lain, nasabah diprioritaskan untuk kunjungan.

## Bagian 5 Asumsi Biaya Penanganan

Untuk perhitungan dampak bisnis threshold, biaya rata-rata per kontak ditetapkan: telepon atau WhatsApp Rp 15 ribu, kunjungan lapangan Rp 150 ribu. Efektivitas penanganan alert diasumsikan mencegah 30% kerugian dari nasabah yang benar-benar memburuk.
