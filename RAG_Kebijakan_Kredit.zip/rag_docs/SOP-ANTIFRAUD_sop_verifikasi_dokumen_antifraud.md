---
doc_id: SOP-ANTIFRAUD
judul: SOP Verifikasi Dokumen dan Anti-Fraud Kredit
jenis: sop
versi: 1.5
berlaku: 2026-01-01
pemilik: Unit Anti-Fraud
bank: Bank Sentosa Raya (fiktif)
---

# SOP Verifikasi Dokumen dan Anti-Fraud Kredit

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Verifikasi Wajib

1. Pencocokan KTP dengan data kependudukan melalui sistem verifikasi identitas.
2. **Verifikasi telepon ke kantor (callback)** wajib untuk plafon di atas Rp 25 juta. Nomor kantor diambil dari sumber independen, bukan dari nomor yang ditulis pemohon.
3. Verifikasi tempat usaha (kunjungan) wajib untuk seluruh pengajuan KMK.

## Bagian 2 Red Flags

Analis wajib menandai pengajuan bila menemukan salah satu kondisi berikut:

- penghasilan di slip gaji berbeda **lebih dari 20%** dengan gaji yang masuk di mutasi rekening;
- nomor telepon kantor sama dengan nomor telepon pribadi pemohon;
- alamat kantor tidak dapat ditemukan atau berupa alamat virtual office tanpa aktivitas;
- terdapat **lebih dari 3 permintaan SLIK dari bank berbeda dalam 30 hari** terakhir;
- dokumen menunjukkan tanda suntingan (font berbeda, tanggal tidak konsisten);
- pemohon menolak dilakukan callback tanpa alasan jelas.

## Bagian 3 Eskalasi

Pengajuan dengan red flag dieskalasi ke Unit Anti-Fraud **paling lambat 1 hari kerja** sejak ditemukan. Selama investigasi, SLA keputusan kredit dihentikan sementara. Pengajuan yang terbukti menggunakan dokumen palsu ditolak dan pemohon dimasukkan ke Daftar Hitam Internal (DHI) selama 5 tahun.

## Bagian 4 Kerahasiaan

Analis tidak boleh memberi tahu pemohon bahwa pengajuannya sedang diinvestigasi oleh Unit Anti-Fraud.
