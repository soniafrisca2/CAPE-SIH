---
doc_id: KBK-UMUM
judul: Kebijakan Umum Perkreditan
jenis: kebijakan
versi: 4.0
berlaku: 2026-01-01
pemilik: Divisi Manajemen Risiko Kredit
bank: Bank Sentosa Raya (fiktif)
---

# Kebijakan Umum Perkreditan

> Dokumen ini adalah dokumen dummy untuk keperluan latihan RAG. Bank Sentosa Raya adalah bank fiktif. Angka dan ketentuan di dalamnya tidak mengacu pada bank atau regulasi mana pun.

## Pasal 1 Tujuan dan Ruang Lingkup

Kebijakan ini menjadi acuan seluruh proses pemberian kredit konsumer dan kredit usaha kecil di Bank Sentosa Raya. Kebijakan berlaku untuk produk Kredit Tanpa Agunan (KTA), Kredit Kendaraan Bermotor (KKB), Kredit Pemilikan Rumah (KPR), dan Kredit Modal Kerja (KMK). Ketentuan khusus tiap produk diatur dalam kebijakan produk masing-masing (KBK-KTA, KBK-KKB, KBK-KPR, KBK-KMK). Bila terdapat perbedaan, ketentuan kebijakan produk yang berlaku.

## Pasal 2 Prinsip Analisa 5C

Setiap analisa kredit wajib menilai lima aspek berikut:

1. **Character**: riwayat pembayaran di bank dan lembaga lain (SLIK), konsistensi keterangan pemohon, dan hasil interview.
2. **Capacity**: kemampuan bayar yang diukur dengan Debt Service Ratio (DSR) dan sisa penghasilan setelah seluruh cicilan.
3. **Capital**: modal sendiri pemohon, misalnya uang muka atau ekuitas usaha.
4. **Collateral**: agunan untuk produk beragunan, dinilai dengan appraisal sesuai ketentuan produk.
5. **Condition**: kondisi pekerjaan, sektor usaha, dan kondisi ekonomi yang memengaruhi kemampuan bayar.

## Pasal 3 Batas Debt Service Ratio (DSR) Umum

DSR adalah total cicilan per bulan (termasuk cicilan baru yang diajukan) dibagi penghasilan bersih per bulan.

| Penghasilan bersih per bulan | DSR maksimum umum |
|---|---|
| di bawah Rp 10 juta | 40% |
| Rp 10 juta atau lebih | 50% |

Kebijakan produk boleh menetapkan batas DSR yang lebih ketat, tetapi tidak boleh lebih longgar dari tabel di atas. Pengecualian DSR hanya dapat diberikan oleh Komite Kredit Cabang dengan alasan tertulis.

## Pasal 4 Kewenangan Memutus Kredit

Kewenangan memutus ditentukan berdasarkan total eksposur nasabah setelah kredit baru (bukan hanya plafon yang diajukan).

| Pemegang kewenangan | Batas total eksposur |
|---|---|
| Analis Kredit Senior | sampai dengan Rp 100 juta |
| Kepala Unit Kredit | di atas Rp 100 juta sampai Rp 500 juta |
| Komite Kredit Cabang | di atas Rp 500 juta sampai Rp 2 miliar |
| Komite Kredit Pusat | di atas Rp 2 miliar |

Analis Kredit (non-senior) tidak memiliki kewenangan memutus. Analis Kredit menyusun rekomendasi dan meneruskannya kepada pemegang kewenangan.

## Pasal 5 Penggunaan Sistem ICA

1. Sistem Intelligent Credit Analyst (ICA) memberikan **rekomendasi** Approve, Further Review, atau Reject. Rekomendasi ICA bukan keputusan kredit.
2. Keputusan akhir tetap berada pada pemegang kewenangan sesuai Pasal 4.
3. Kasus dengan rekomendasi **Further Review** wajib diputus minimal oleh Analis Kredit Senior, walaupun eksposurnya di bawah Rp 100 juta.
4. Keputusan yang berbeda dengan rekomendasi ICA disebut **override** dan wajib dicatat dengan kode override sesuai SOP-ANALISA Bagian 6.
5. Threshold skor ICA ditetapkan oleh Komite Manajemen Risiko dan ditinjau setiap kuartal.

## Pasal 6 Larangan Pemberian Kredit

Kredit tidak boleh diberikan kepada:

- pemohon yang tercantum dalam Daftar Hitam Internal (DHI);
- pemohon dengan kolektibilitas 4 atau 5 di lembaga mana pun dalam 24 bulan terakhir;
- pihak terkait bank (pengurus, pemegang saham, dan keluarganya) kecuali melalui Komite Kredit Pusat;
- pemohon yang terindikasi memberikan dokumen palsu sesuai SOP-ANTIFRAUD.

## Pasal 7 Prinsip Non-Diskriminasi

Jenis kelamin, agama, suku, status pernikahan, dan kota domisili tidak boleh menjadi dasar keputusan kredit. Atribut tersebut tidak digunakan sebagai fitur model ICA, tetapi hasil keputusan diaudit secara berkala dengan uji *disparate impact* minimal 0,8.

## Pasal 8 Peninjauan Kebijakan

Kebijakan ini ditinjau paling lambat setiap 12 bulan oleh Divisi Manajemen Risiko Kredit dan disahkan oleh Direktur Risiko.
