---
doc_id: SOP-INTERVIEW
judul: SOP Interview Pemohon Baru
jenis: sop
versi: 1.2
berlaku: 2026-04-01
pemilik: Divisi Operasional Kredit
bank: Bank Sentosa Raya (fiktif)
---

# SOP Interview Pemohon Baru

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Tujuan

Interview menggali informasi yang tidak tersedia di dokumen formal, terutama stabilitas penghasilan, beban cicilan di lembaga lain, dan riwayat pembayaran. Interview dilakukan oleh agent interview ICA dan dipantau analis.

## Bagian 2 Daftar Pertanyaan Baku

| Kode | Pertanyaan |
|---|---|
| Q01 | Bagaimana kondisi pendapatan Anda dalam beberapa bulan terakhir? |
| Q02 | Apakah saat ini Anda memiliki cicilan atau kewajiban kredit lain? |
| Q03 | Bagaimana riwayat pembayaran cicilan Anda sebelumnya? |
| Q04 | Apakah ada perubahan kondisi keuangan akhir-akhir ini? |
| Q05 | Apa tujuan utama pengajuan kredit? |
| Q06 | Bagaimana kondisi usaha atau pekerjaan Anda saat ini? |

## Bagian 3 Pertanyaan Lanjutan (Follow-up)

- Agent boleh mengajukan **maksimal 1 pertanyaan lanjutan** untuk setiap pertanyaan baku bila jawaban belum cukup jelas.
- Pertanyaan lanjutan maksimal 30 kata dan harus berupa pertanyaan.
- Target durasi seluruh interview maksimal 15 menit.

## Bagian 4 Larangan

Selama interview, agent maupun analis **dilarang meminta**: NIK lengkap, nomor rekening, PIN, password, kode OTP, dan alamat rumah lengkap. Data identitas dikumpulkan melalui form resmi, bukan melalui percakapan interview. Bila pemohon menuliskan data pribadi secara sukarela, sistem menyamarkannya sebelum diproses model bahasa.

## Bagian 5 Indikasi Manipulasi

Bila jawaban pemohon berisi upaya mengarahkan sistem (misalnya meminta sistem mengubah penilaian), interview ditandai dengan flag **indikasi manipulasi** dan rekomendasi otomatis menjadi Further Review.

## Bagian 6 Penyimpanan Rekaman

Transkrip interview disimpan selama **5 tahun** sejak tanggal interview dan hanya dapat diakses oleh analis, Quality Assurance, dan auditor internal.
