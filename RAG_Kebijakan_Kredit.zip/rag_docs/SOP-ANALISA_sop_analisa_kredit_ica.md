---
doc_id: SOP-ANALISA
judul: SOP Analisa Kredit dengan Sistem ICA
jenis: sop
versi: 2.0
berlaku: 2026-04-01
pemilik: Divisi Operasional Kredit
bank: Bank Sentosa Raya (fiktif)
---

# SOP Analisa Kredit dengan Sistem ICA

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Ruang Lingkup

SOP ini mengatur langkah kerja Analis Kredit sejak menerima pengajuan sampai menyerahkan rekomendasi kepada pemegang kewenangan, dengan memanfaatkan sistem Intelligent Credit Analyst (ICA).

## Bagian 2 Langkah Kerja

1. Analis memasukkan `customer_id` pemohon ke ICA.
2. Bila `customer_id` ditemukan (nasabah existing), ICA menampilkan profil, riwayat kredit, riwayat pembayaran, skor Credit Risk, dan status Early Warning. Analis mengisi form pengajuan.
3. Bila `customer_id` tidak ditemukan (pemohon baru), ICA menjalankan interview sesuai SOP-INTERVIEW, lalu analis mengisi form profil dan form pengajuan. ICA hanya mengeluarkan skor Credit Risk; Early Warning tidak dikeluarkan untuk pemohon baru.
4. Analis memeriksa rekomendasi, PD terkalibrasi, faktor risiko, dan flag guardrail yang ditampilkan ICA.
5. Analis melakukan verifikasi dokumen sesuai SOP-ANTIFRAUD.
6. Analis mengecek SLIK untuk riwayat di lembaga lain.
7. Analis menyusun memo rekomendasi dan meneruskannya kepada pemegang kewenangan sesuai KBK-UMUM Pasal 4.
8. Keputusan dan alasannya dicatat di sistem paling lambat pada hari keputusan dibuat.

## Bagian 3 Service Level Agreement (SLA)

| Produk | SLA keputusan sejak dokumen lengkap |
|---|---|
| KTA | 2 hari kerja |
| KKB | 3 hari kerja |
| KPR | 7 hari kerja |
| KMK | 10 hari kerja |

## Bagian 4 Penanganan Rekomendasi Further Review

Untuk rekomendasi Further Review, analis wajib memeriksa minimal tiga hal sebelum menyusun memo:

1. verifikasi penghasilan dengan dokumen sumber (slip gaji atau mutasi rekening);
2. riwayat SLIK 24 bulan terakhir;
3. konsistensi jawaban interview dengan data form (khususnya cicilan lain dan penghasilan).

Kasus Further Review diputus minimal oleh Analis Kredit Senior sesuai KBK-UMUM Pasal 5 ayat 3.

## Bagian 5 Nasabah dengan Flag Guardrail

Bila ICA menampilkan flag "nasabah sedang default" atau "nasabah sedang menunggak", pengajuan kredit baru tidak dapat diproses sampai tunggakan diselesaikan, kecuali pengajuan tersebut merupakan bagian dari restrukturisasi sesuai PB-RESTRU.

## Bagian 6 Override Rekomendasi ICA

Setiap keputusan yang berbeda dari rekomendasi ICA wajib menggunakan salah satu kode override berikut:

| Kode | Alasan override | Persetujuan tambahan |
|---|---|---|
| OVR-01 | Ada agunan tambahan yang tidak dinilai ICA | tidak ada |
| OVR-02 | Ada penjamin (personal guarantee) dengan kemampuan bayar memadai | tidak ada |
| OVR-03 | Data ICA tidak lengkap atau belum diperbarui | tidak ada |
| OVR-04 | Pertimbangan relasi bisnis strategis | wajib persetujuan Kepala Unit Kredit |
| OVR-05 | Koreksi kesalahan input data oleh analis | tidak ada |

Tingkat override dipantau per analis. Bila override seorang analis melebihi **10% dari keputusan dalam satu bulan**, Unit Quality Assurance melakukan review sampel keputusan analis tersebut.
