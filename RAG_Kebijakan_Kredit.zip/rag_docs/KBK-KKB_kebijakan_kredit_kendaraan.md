---
doc_id: KBK-KKB
judul: Kebijakan Produk Kredit Kendaraan Bermotor (KKB)
jenis: kebijakan
versi: 2.3
berlaku: 2026-01-15
pemilik: Divisi Kredit Konsumer
bank: Bank Sentosa Raya (fiktif)
---

# Kebijakan Produk Kredit Kendaraan Bermotor (KKB)

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Objek Pembiayaan

KKB membiayai pembelian mobil dan sepeda motor, baik baru maupun bekas, untuk penggunaan pribadi. Kendaraan untuk usaha angkutan umum dibiayai melalui produk KMK.

## Bagian 2 Uang Muka Minimum

| Jenis kendaraan | Uang muka (down payment) minimum |
|---|---|
| Mobil baru | 20% dari harga kendaraan |
| Mobil bekas | 25% dari harga kendaraan |
| Sepeda motor baru | 15% dari harga kendaraan |
| Sepeda motor bekas | tidak dibiayai |

## Bagian 3 Tenor dan Usia Kendaraan

- Tenor maksimal mobil: 60 bulan.
- Tenor maksimal sepeda motor: 36 bulan.
- Untuk mobil bekas, usia kendaraan maksimal **10 tahun pada saat kredit lunas**. Contoh: mobil tahun 2020 dengan tenor 5 tahun yang dimulai tahun 2026 akan berusia 11 tahun saat lunas, sehingga tenor harus diperpendek.

## Bagian 4 Batas DSR KKB

DSR maksimum KKB mengikuti batas umum KBK-UMUM Pasal 3, dengan batas tertinggi 40% untuk semua tingkat penghasilan.

## Bagian 5 Asuransi dan Agunan

1. Kendaraan menjadi agunan dengan pengikatan fidusia.
2. Asuransi *all risk* wajib untuk tahun pertama; tahun berikutnya minimal asuransi *total loss only* (TLO).
3. BPKB disimpan oleh bank sampai kredit lunas.

## Bagian 6 Penilaian Kendaraan Bekas

Harga mobil bekas mengacu pada daftar harga pasar internal yang diperbarui setiap bulan. Bila harga transaksi lebih tinggi 10% atau lebih dari harga pasar internal, analis wajib meminta penilaian ulang oleh petugas appraisal.
