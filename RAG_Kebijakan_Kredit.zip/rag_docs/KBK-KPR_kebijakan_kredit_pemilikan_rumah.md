---
doc_id: KBK-KPR
judul: Kebijakan Produk Kredit Pemilikan Rumah (KPR)
jenis: kebijakan
versi: 5.0
berlaku: 2026-03-01
pemilik: Divisi Kredit Konsumer
bank: Bank Sentosa Raya (fiktif)
---

# Kebijakan Produk Kredit Pemilikan Rumah (KPR)

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Objek Pembiayaan

KPR membiayai pembelian rumah tapak, apartemen, dan renovasi rumah yang sudah dimiliki. Tanah kosong tidak dibiayai melalui KPR.

## Bagian 2 Loan to Value (LTV)

LTV adalah plafon kredit dibagi nilai agunan hasil appraisal.

| Fasilitas KPR ke- | LTV maksimum |
|---|---|
| Rumah pertama | 85% |
| Rumah kedua | 80% |
| Rumah ketiga dan seterusnya | 70% |

Untuk renovasi rumah, LTV maksimal 60% dari nilai rumah setelah renovasi.

## Bagian 3 Tenor dan Usia

- Tenor maksimal 20 tahun.
- Usia pemohon maksimal 65 tahun saat kredit lunas (pensiunan dengan penghasilan tetap maksimal 70 tahun).

## Bagian 4 Batas DSR KPR

DSR maksimum KPR adalah **45%** untuk penghasilan di bawah Rp 10 juta dan mengikuti batas umum 50% untuk penghasilan Rp 10 juta atau lebih.

## Bagian 5 Appraisal Agunan

1. Agunan dengan nilai sampai Rp 1 miliar dinilai oleh appraisal internal.
2. Agunan dengan nilai di atas Rp 1 miliar wajib dinilai oleh **Kantor Jasa Penilai Publik (KJPP) independen** yang terdaftar sebagai rekanan bank.
3. Hasil appraisal berlaku 6 bulan.

## Bagian 6 Suku Bunga

KPR menggunakan bunga tetap (*fixed*) selama 3 tahun pertama, kemudian bunga mengambang (*floating*) mengikuti suku bunga dasar kredit bank ditambah marjin 3%.
