---
doc_id: KBK-KMK
judul: Kebijakan Produk Kredit Modal Kerja Usaha Kecil (KMK)
jenis: kebijakan
versi: 1.8
berlaku: 2025-11-01
pemilik: Divisi Kredit Usaha Kecil
bank: Bank Sentosa Raya (fiktif)
---

# Kebijakan Produk Kredit Modal Kerja Usaha Kecil (KMK)

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Kriteria Usaha

- Usaha telah berjalan minimal **2 tahun** di lokasi atau bidang yang sama.
- Pemilik usaha berusia 21 sampai 65 tahun.
- Usaha memiliki izin usaha yang masih berlaku (NIB).

## Bagian 2 Kebutuhan Modal Kerja dan Plafon

Plafon KMK maksimal **70% dari kebutuhan modal kerja** satu siklus usaha. Kebutuhan modal kerja dihitung dari perputaran persediaan, piutang, dan utang dagang. Plafon maksimal produk adalah Rp 5 miliar.

## Bagian 3 Kemampuan Bayar Usaha

Kemampuan bayar usaha diukur dengan **Debt Service Coverage Ratio (DSCR)**, yaitu laba operasional sebelum bunga dan penyusutan dibagi total kewajiban pokok dan bunga dalam periode yang sama. DSCR minimum adalah **1,25 kali**. Untuk usaha dengan omzet musiman, DSCR dihitung per kuartal dan nilai terendah harus tetap minimal 1,0 kali.

## Bagian 4 Laporan Keuangan

| Plafon | Laporan keuangan yang diminta |
|---|---|
| sampai Rp 500 juta | laporan keuangan sederhana 2 tahun terakhir dan rekening koran 12 bulan |
| di atas Rp 500 juta sampai Rp 5 miliar | laporan keuangan 2 tahun terakhir yang disusun akuntan |
| di atas Rp 5 miliar | tidak tersedia di produk KMK, diproses sebagai kredit komersial |

## Bagian 5 Agunan

KMK wajib dijamin agunan dengan nilai likuidasi minimal 100% dari plafon. Agunan dapat berupa tanah dan bangunan, kendaraan, atau deposito.

## Bagian 6 Tenor dan Peninjauan

KMK diberikan dalam bentuk fasilitas *revolving* dengan jangka waktu 12 bulan dan dapat diperpanjang setelah peninjauan tahunan. Peninjauan tahunan memeriksa omzet, DSCR, dan riwayat pembayaran selama 12 bulan terakhir.
