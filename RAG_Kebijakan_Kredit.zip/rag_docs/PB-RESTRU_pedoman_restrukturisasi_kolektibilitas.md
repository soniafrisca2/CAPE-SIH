---
doc_id: PB-RESTRU
judul: Pedoman Restrukturisasi dan Kolektibilitas Internal
jenis: pedoman
versi: 2.1
berlaku: 2026-01-01
pemilik: Divisi Collection & Recovery
bank: Bank Sentosa Raya (fiktif)
---

# Pedoman Restrukturisasi dan Kolektibilitas Internal

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif. Pemetaan kolektibilitas di bawah adalah ringkasan internal untuk latihan, bukan kutipan regulasi.

## Bagian 1 Kolektibilitas Internal

| Kolektibilitas | Nama | Hari tunggakan (DPD) |
|---|---|---|
| Kol 1 | Lancar | 0 |
| Kol 2 | Dalam Perhatian Khusus | 1–90 |
| Kol 3 | Kurang Lancar | 91–120 |
| Kol 4 | Diragukan | 121–180 |
| Kol 5 | Macet | di atas 180 |

Kredit dengan kolektibilitas 3, 4, dan 5 dikategorikan sebagai kredit bermasalah (*non-performing loan*).

## Bagian 2 Syarat Restrukturisasi

1. Nasabah masih memiliki penghasilan atau prospek usaha yang memadai untuk membayar setelah restrukturisasi.
2. Restrukturisasi diutamakan untuk nasabah dengan DPD maksimal 90 hari.
3. Restrukturisasi maksimal **2 kali** selama masa kredit.
4. Nasabah menandatangani surat permohonan dan menyerahkan bukti penurunan penghasilan.

## Bagian 3 Skema Restrukturisasi

- Perpanjangan tenor maksimal **24 bulan** dari tenor awal.
- Penurunan suku bunga maksimal 3 poin persentase.
- Masa tenggang (*grace period*) pembayaran pokok maksimal **6 bulan**; bunga tetap dibayar.
- Kombinasi skema dapat diberikan dengan persetujuan pemegang kewenangan.

## Bagian 4 Kewenangan Persetujuan Restrukturisasi

| Outstanding kredit | Pemegang kewenangan |
|---|---|
| sampai Rp 500 juta | Kepala Unit Kredit |
| di atas Rp 500 juta | Komite Kredit Cabang |

## Bagian 5 Status Setelah Restrukturisasi

Kredit hasil restrukturisasi tetap dipantau minimal 6 bulan. Bila nasabah membayar tepat waktu selama 3 bulan berturut-turut, kolektibilitas dapat diperbaiki satu tingkat.
