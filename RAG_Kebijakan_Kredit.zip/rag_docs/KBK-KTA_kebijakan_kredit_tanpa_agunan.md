---
doc_id: KBK-KTA
judul: Kebijakan Produk Kredit Tanpa Agunan (KTA)
jenis: kebijakan
versi: 3.1
berlaku: 2026-02-01
pemilik: Divisi Kredit Konsumer
bank: Bank Sentosa Raya (fiktif)
---

# Kebijakan Produk Kredit Tanpa Agunan (KTA)

> Dokumen dummy untuk latihan RAG. Bank Sentosa Raya adalah bank fiktif.

## Bagian 1 Definisi Produk

KTA adalah kredit konsumtif tanpa agunan untuk keperluan pribadi seperti renovasi, pendidikan, biaya kesehatan, atau konsolidasi utang. KTA tidak boleh digunakan untuk modal usaha; pemohon dengan kebutuhan modal usaha diarahkan ke produk KMK.

## Bagian 2 Kriteria Pemohon

| Kriteria | Ketentuan |
|---|---|
| Usia | 21 sampai 60 tahun saat pengajuan, dan maksimal 65 tahun saat kredit lunas |
| Penghasilan minimum | Rp 4 juta per bulan (penghasilan bersih) |
| Karyawan tetap | masa kerja minimal 12 bulan di perusahaan saat ini |
| Karyawan kontrak | masa kerja minimal 24 bulan dan sisa kontrak tidak boleh lebih pendek dari tenor KTA |
| Wiraswasta / pekerja lepas | usaha atau pekerjaan berjalan minimal 24 bulan, dibuktikan dengan rekening koran |
| Kewarganegaraan | Warga Negara Indonesia |

## Bagian 3 Plafon dan Tenor

- Plafon KTA: minimal Rp 5 juta dan maksimal Rp 300 juta.
- Plafon tidak boleh melebihi **12 kali penghasilan bersih bulanan**.
- Tenor: 12 sampai 60 bulan.
- Untuk pemohon karyawan kontrak, plafon maksimal 6 kali penghasilan bulanan.

## Bagian 4 Batas DSR KTA

DSR maksimum untuk KTA adalah **35%**, lebih ketat daripada batas DSR umum pada KBK-UMUM Pasal 3. Batas ini berlaku untuk seluruh tingkat penghasilan. Pengajuan dengan DSR di atas 35% wajib ditolak atau plafon diturunkan sampai DSR berada di bawah 35%.

## Bagian 5 Suku Bunga Berdasarkan Grade Risiko

Suku bunga efektif per tahun ditentukan oleh grade risiko yang dipetakan dari skor ICA:

| Grade | Rentang PD terkalibrasi | Bunga efektif per tahun |
|---|---|---|
| A | di bawah 2% | 11% |
| B | 2% sampai di bawah 5% | 13,5% |
| C | 5% sampai di bawah 10% | 16% |
| D | 10% sampai di bawah 15% | 19% |
| E | 15% atau lebih | tidak diberikan KTA |

## Bagian 6 Dokumen Wajib

1. KTP elektronik.
2. NPWP untuk plafon di atas Rp 50 juta.
3. Slip gaji 3 bulan terakhir (karyawan) atau rekening koran 6 bulan terakhir (wiraswasta).
4. Surat keterangan kerja untuk karyawan dengan masa kerja di bawah 24 bulan.

## Bagian 7 Pelunasan Dipercepat

Pelunasan dipercepat dikenakan penalti 2% dari sisa pokok jika dilakukan dalam 12 bulan pertama, dan bebas penalti setelahnya.
