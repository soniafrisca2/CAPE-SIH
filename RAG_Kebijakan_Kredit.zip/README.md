# RAG Kebijakan & SOP Kredit (Hybrid BM25 + FAISS HNSW, Gemma 4 E4B)

Isi paket:
- `RAG_Kebijakan_Kredit_Hybrid.ipynb`: notebook lengkap (load → chunk → HNSW + BM25 → `hybrid_retrieve()` → chain LangChain + Gemma → evaluasi).
- `rag_docs/`: 11 dokumen dummy Markdown milik bank fiktif "Bank Sentosa Raya" (kebijakan umum, KTA, KKB, KPR, KMK, SOP analisa, SOP interview, SOP anti-fraud, playbook Early Warning, pedoman restrukturisasi, FAQ).
- `rag_eval_set.json`: 26 pertanyaan uji (24 dalam cakupan dengan dokumen & kalimat kunci jawaban, 2 di luar cakupan).

## Cara run (VS Code + runtime Colab GPU)
1. Upload folder `rag_docs/` dan `rag_eval_set.json` ke folder kerja, `/content`, atau `MyDrive` (dicari otomatis).
2. Simpan token Hugging Face di Colab Secrets sebagai `HF_TOKEN` dan setujui lisensi `google/gemma-4-E4B-it`.
3. Run All. Cell pertama meng-install `langchain-*`, `faiss-cpu`, `rank_bm25`, `sentence-transformers`, `transformers` (sekali per runtime).

Perkiraan waktu: install ±1–2 menit, unduh embedding `BAAI/bge-m3` (±2 GB) dan Gemma 4 E4B (±16 GB) pertama kali beberapa menit, sisanya < 5 menit.

## Konfigurasi utama (cell Setup)
`EMBED_MODEL`, `LLM_ID`, `CHUNK_SIZE`/`CHUNK_OVERLAP`, `HNSW_M`/`EF_CONSTRUCTION`/`EF_SEARCH`, `FETCH_K`, `TOP_K`, `RRF_K`.

## `hybrid_retrieve(query, k=5, fetch_k=20, method="rrf", alpha=0.5, rrf_k=60, filter=None)`
- `method="rrf"`: Reciprocal Rank Fusion (berbasis urutan, default).
- `method="weighted"`: skor min-max dense & BM25 digabung α : (1 − α).
- `filter`: filter metadata, contoh `{"jenis": "sop"}` atau `{"doc_id": "KBK-KTA"}`.
- Hasil: `list[Document]`, metadata berisi `hybrid_score`, `dense_rank`, `sparse_rank`, `dense_score`, `sparse_score`.

## Output (`rag_artifacts/`)
`faiss_hnsw/` (index tersimpan) · `rag_eval_retrieval.csv` · `rag_eval_generation.csv`
